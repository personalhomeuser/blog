<?php

return [

   /*
     * Environment to show the debug bar on.
     */
    'enabled_environment' => env('DEBUG_BAR_ENVIRONMENT'),

];