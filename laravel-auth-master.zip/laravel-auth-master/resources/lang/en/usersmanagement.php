<?php

return [

	'createSuccess'             => 'Successfully created user! ',
	'updateSuccess'             => 'Successfully updated user! ',
	'deleteSuccess'             => 'Successfully deleted user! ',
	'deleteSelfError'           => 'You cannot delete yourself! ',

];
